import React from "react";
import { RiArrowLeftSLine } from "react-icons/io";
import ArrowBackIosIcon from "@material-ui/icons/ArrowBackIos";
import "../../css/Comment.css";

const Comment = () => {
  const onClickBack = () => {
    console.log("뒤로가기 처리");
  };
  return <div></div>;
};

export default Comment;
