import React from "react";

const Forgot = () => {
  return (
    <div>
      <h1>hello</h1>
    </div>
  );
};

export default Forgot;
