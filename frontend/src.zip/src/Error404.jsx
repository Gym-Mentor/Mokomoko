import React from "react";

const Error404 = () => {
  return (
    <div>
      <img src="../../../public/logo-no-back.png" alt="d" />
      <h1>페이지가 존재하지 않습니다.</h1>
    </div>
  );
};

export default Error404;
